public class App {
    public static void main(String[] args) {

        PlayerCharacter player1 = PlayerCharacter.randomCharacter("Joakim");

        System.out.println(player1);

    }
}
