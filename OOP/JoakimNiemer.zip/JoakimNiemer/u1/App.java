import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class App {
    public static void main(String[] args) {

        Box b1 = new Box(1.23, 23.2, 10);
        Box b2 = new Box();

        System.out.println(b1);
        System.out.println(b2);

    }
}
